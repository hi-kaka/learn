from django.contrib import admin
from .models import *


# class UserInfoAdmin(admin.ModelAdmin):
#     list_display = ['user_name', 'user_passwd', 'user_level']
#
# admin.site.register(UserInfo, UserInfoAdmin)
