# 运维自动化工程

我们工程代码将陆续开源并对外，更新在githup，地址：
https://github.com/iopsgroup/imoocc

第一期：自动化资产扫描探测


常见问题：

1、适用人群

欢迎对Devops感兴趣，并且愿意参与开发的人员学习使用。
使用人员：需具备python2.7的开发编程基础。了解django框架，熟悉运维体系内容。


2、这套工程如何获取具体技术实现和技术支持？可以在线提问吗？

这套工程提供给慕课网的实战课程使用。实战课程将提供视频的体系化讲解，并且提供问题答疑。
地址如下：
https://coding.imooc.com/class/160.html

3、这套工程的版本是否支持python3

工程是基于python2.7开发的，不支持py3。
目前已经将imoocc工程升级到python3.6、Django1.11.6版本。如需要获取，可以选择慕课网实战区购买。
或者联系jeson@imoocc.com并说明用意。




