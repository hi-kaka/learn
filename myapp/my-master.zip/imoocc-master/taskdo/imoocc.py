# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.test import TestCase

# Create your tests here.
uname = raw_input("input your name")
name  = u"imoocc"
if uname == name:
    print u"You name is : 幕客"